﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.Bot.Connector.DirectLine;
using Newtonsoft.Json;


namespace DirectLineAutomotiveChatBot
{
    public partial class EJAutomotiveChatBot : System.Web.UI.Page
    {
        private static string directLineSecret = ConfigurationManager.AppSettings["DirectLineSecret"];
        private static string botId = ConfigurationManager.AppSettings["BotId"];
        private static string fromUser = "DirectLineSampleClientUser";

        protected void Page_Load(object sender, EventArgs e)
        {
            //StartBotConversation().Wait();
        }

        private static async Task StartBotConversation()
        {
            DirectLineClient client = new DirectLineClient(directLineSecret);

            var conversation = await client.Conversations.StartConversationAsync();

            new System.Threading.Thread(async () => await ReadBotMessagesAsync(client, conversation.ConversationId)).Start();

            Console.Write("Command> ");
            try
            {
                while (true)
                {
                    string input = Console.ReadLine().Trim();

                    if (input.ToLower() == "exit")
                    {
                        break;
                    }
                    else
                    {
                        if (input.Length > 0)
                        {
                            Activity userMessage = new Activity
                            {
                                From = new ChannelAccount(fromUser),
                                Text = input,
                                Type = ActivityTypes.Message
                            };

                            await client.Conversations.PostActivityAsync(conversation.ConversationId, userMessage);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
        }

        private static async Task ReadBotMessagesAsync(DirectLineClient client, string conversationId)
        {
            try
            {
                string watermark = null;

                while (true)
                {
                    var activitySet = await client.Conversations.GetActivitiesAsync(conversationId, watermark);
                    watermark = activitySet?.Watermark;

                    var activities = from x in activitySet.Activities
                                     where x.From.Id == botId
                                     select x;

                    foreach (Activity activity in activities)
                    {
                        Console.WriteLine(activity.Text);

                        if (activity.Attachments != null)
                        {
                            foreach (Attachment attachment in activity.Attachments)
                            {
                                switch (attachment.ContentType)
                                {
                                    case "application/vnd.microsoft.card.hero":
                                        RenderHeroCard(attachment);
                                        break;

                                    case "image/png":
                                        Console.WriteLine($"Opening the requested image '{attachment.ContentUrl}'");

                                        //Process.Start(attachment.ContentUrl);
                                        break;
                                }
                            }
                        }

                        Console.Write("Command> ");
                    }

                    await Task.Delay(TimeSpan.FromSeconds(1)).ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
        }

        private static void RenderHeroCard(Attachment attachment)
        {
            try
            {
                const int Width = 70;
                Func<string, string> contentLine = (content) => string.Format($"{{0, -{Width}}}", string.Format("{0," + ((Width + content.Length) / 2).ToString() + "}", content));

                var heroCard = JsonConvert.DeserializeObject<HeroCard>(attachment.Content.ToString());

                if (heroCard != null)
                {
                    Console.WriteLine("/{0}", new string('*', Width + 1));
                    if (heroCard.Title != null)
                        Console.WriteLine("*{0}*", contentLine(heroCard.Title));
                    Console.WriteLine("*{0}*", new string(' ', Width));
                    if (heroCard.Text != null)
                        Console.WriteLine("*{0}*", contentLine(heroCard.Text));
                    Console.WriteLine("{0}/", new string('*', Width + 1));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
        }
    }
}